# SkillSwap — Open Innovation Track (H0: Hack the Zero)

Students trade skills instead of money: *"I know SQL, you know Photoshop — let's teach each other."*

Stack: **Next.js 14 (App Router) deployed on Vercel** + **AWS DynamoDB** (data) + **AWS S3** (proof-of-skill file uploads).

## 1. Quick start

```bash
npm install
cp .env.example .env.local   # fill in your AWS keys
npm run seed                 # creates all DynamoDB tables + indexes
npm run dev                  # http://localhost:3000
```

### AWS setup (5 minutes)
1. Create an IAM user with `AmazonDynamoDBFullAccess` and `AmazonS3FullAccess` (or scoped policies for production).
2. Copy the Access Key / Secret into `.env.local`.
3. Create an S3 bucket (any name) for proof uploads, put its name in `S3_BUCKET_NAME`.
4. Run `npm run seed` — this creates 9 on-demand (pay-per-request) DynamoDB tables, so **you pay $0 until someone actually uses the app.**
5. Deploy to Vercel, add the same env vars in Vercel → Project → Settings → Environment Variables.

## 2. Why DynamoDB (and how it's modeled)

DynamoDB is schemaless and serverless — perfect for a hackathon: no servers to manage, scales to zero cost, and millisecond reads. Tables:

| Table | Key | Purpose |
|---|---|---|
| `Users` | PK `userId`, GSI `EmailIndex` | accounts, ratings, premium status |
| `Skills` | PK `skillId` | master catalog of all skills ever added |
| `UserSkills` | PK `userId` SK `skillId`, GSI `SkillIndex` (PK `skillId`) | what each user knows + proof |
| `LearningGoals` | same shape as UserSkills | what each user wants to learn |
| `SwapRequests` | PK `requestId`, GSI on `fromUserId`/`toUserId` | the "chat request" / swap lifecycle |
| `Messages` | PK `conversationId`, SK `timestamp#id` | 1:1 chat, deterministic conversation id |
| `Reviews` | PK `revieweeId`, SK `reviewId` | ratings & reviews |
| `Certificates` | PK `userId`, SK `certificateId` | auto-issued completion certificates |
| `Notifications` | PK `userId`, SK `timestamp#id` | in-app notification feed |

**The matching engine** (`/app/api/match/route.js`) is the core trick: for every skill you *want*, it queries `UserSkills.SkillIndex` to instantly find everyone who *knows* it (no full table scan). Then it checks whether each candidate also wants something you know — that flips a match from "one-way" to "🔁 mutual," which is ranked highest. This is O(goals × candidates) instead of O(all users), so it stays fast as the platform grows.

## 3. Feature checklist (your requirements)

- ✅ Register / Login (JWT, bcrypt-hashed passwords, httpOnly cookie + bearer token)
- ✅ Add skills you know + proof (link to certificate/GitHub/portfolio, or free-text proof)
- ✅ Add skills you want to learn (with urgency level)
- ✅ Matching system (mutual-swap aware, rating-weighted ranking)
- ✅ Swap request system (doubles as the "chat request" — pending/accepted/declined/completed)
- ✅ 1:1 Chat once matched (polling every 3s for near-real-time feel without needing WebSocket infra)
- ✅ Ratings & reviews (running average recalculated on each new review)
- ✅ Dashboard (single aggregated API call: stats, pending requests, skills, goals)
- ✅ Premium profiles (boost in match ranking, verified certificates)
- ✅ Featured skills listing (homepage carousel for premium users)
- ✅ Certificate generation (auto-unlocks after 3+ reviews of 4★+ for a skill)

## 4. Suggested additions (to make it more useful & defensible to judges)

1. **Trust/verification layer** — let the *receiver* of a teaching session confirm "yes, this happened" before a swap counts toward certificates. Prevents fake credential farming.
2. **Skill credits wallet** (already stubbed: `user.credits`) — instead of strict 1:1 swaps, let students bank credits: teach someone now, redeem a lesson from anyone later. Removes the "I need to find someone who wants exactly my skill" bottleneck.
3. **Group/cohort sessions** — one student teaches 5 students at once for 5x the credits; great for popular skills like Excel or public speaking.
4. **Calendar integration** — auto-generate a scheduling link once a swap is accepted (Google Calendar API) instead of relying purely on chat.
5. **Skill verification via quiz** — a short auto-graded quiz per skill (e.g. 5 SQL questions) to add a "verified" badge without requiring a human reviewer.
6. **Report/block system** — basic trust & safety: block a user, report inappropriate messages.
7. **University leaderboard** — gamify with "Top 10 most active swappers at [College]" to drive viral campus adoption — a strong growth lever for judges who care about GTM.
8. **Push notifications via SNS** — AWS SNS for real swap-request/message alerts (currently stored in the `Notifications` table, ready to wire into SNS/SES).

## 5. Revenue model recap

- **Premium profiles** ($3/mo or $25/yr): top-ranked in matches, verified certificate badges with public shareable links, unlimited monthly swap requests (free tier capped at 5/month — enforce this in `swap-requests/route.js` by counting `SwapRequests` per month, marked as a TODO for production).
- **Featured skill listings**: premium users' skills appear in the homepage carousel (`/api/featured`).
- **Certificate generation**: free = basic PDF-style badge; premium = "verified" badge with a public shareable URL (`/certificates/[id]`) — useful on a student's resume/LinkedIn, which is the actual emotional hook for upgrading.

## 6. Project structure

```
app/
  api/            <- all backend routes (DynamoDB + S3 logic lives here)
  login, register, dashboard, profile, matches, chat  <- pages
lib/
  dynamodb.js     <- AWS SDK client + table name registry
  auth.js         <- JWT + bcrypt helpers
  api.js          <- frontend fetch wrapper
scripts/
  createTables.js <- run once to provision DynamoDB
```

## 7. Known limitations (be upfront with judges)

- Chat uses polling, not WebSockets — fine for a hackathon demo; swap for API Gateway WebSockets + DynamoDB Streams for true real-time at scale.
- `/api/featured` uses a `Scan` for simplicity; denormalize an `isPremium` flag onto `UserSkills` items in production to avoid scanning.
- No payment gateway wired in — `/api/premium` simulates the upgrade; swap in Stripe Checkout + webhook before going live.
