import Link from "next/link";

export default function Home() {
  return (
    <main className="max-w-5xl mx-auto px-6 py-20 text-center">
      <h1 className="text-5xl font-extrabold text-slate-900">
        Learn anything. <span className="text-brand-600">Pay with skill, not money.</span>
      </h1>
      <p className="mt-5 text-lg text-slate-600 max-w-2xl mx-auto">
        SkillSwap connects students who know something with students who want to learn it.
        Know SQL? Trade lessons with someone who knows Photoshop. No tuition, just teaching.
      </p>
      <div className="mt-8 flex justify-center gap-4">
        <Link href="/register" className="btn-primary">Get started — it's free</Link>
        <Link href="/login" className="px-5 py-2.5 rounded-lg border border-slate-300 font-semibold">
          Log in
        </Link>
      </div>

      <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
        <div className="card">
          <h3 className="font-bold text-lg mb-2">1. List your skills</h3>
          <p className="text-slate-600 text-sm">Add what you know with proof — a certificate, GitHub repo, or portfolio link.</p>
        </div>
        <div className="card">
          <h3 className="font-bold text-lg mb-2">2. Get matched</h3>
          <p className="text-slate-600 text-sm">Our matching engine finds students who can teach what you want and want what you know.</p>
        </div>
        <div className="card">
          <h3 className="font-bold text-lg mb-2">3. Swap & grow</h3>
          <p className="text-slate-600 text-sm">Chat, schedule a session, swap skills, then rate each other and earn certificates.</p>
        </div>
      </div>
    </main>
  );
}
