"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";

export default function ProfilePage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [skills, setSkills] = useState([]);
  const [goals, setGoals] = useState([]);
  const [certs, setCerts] = useState([]);
  const [msg, setMsg] = useState("");

  const [skillForm, setSkillForm] = useState({
    skillName: "", category: "", proficiency: "Intermediate", proofType: "description", proofUrl: "", proofDescription: "",
  });
  const [goalForm, setGoalForm] = useState({ skillName: "", category: "", urgency: "Flexible" });

  useEffect(() => {
    const stored = localStorage.getItem("user");
    if (!stored) {
      router.push("/login");
      return;
    }
    const u = JSON.parse(stored);
    setUser(u);
    refresh(u.userId);
  }, [router]);

  async function refresh(userId) {
    const [s, g, c] = await Promise.all([api.getSkills(userId), api.getGoals(userId), api.getCertificates()]);
    setSkills(s.skills);
    setGoals(g.goals);
    setCerts(c.certificates);
  }

  async function addSkill(e) {
    e.preventDefault();
    setMsg("");
    try {
      await api.addSkill(skillForm);
      setSkillForm({ skillName: "", category: "", proficiency: "Intermediate", proofType: "description", proofUrl: "", proofDescription: "" });
      refresh(user.userId);
      setMsg("Skill added!");
    } catch (err) {
      setMsg(err.message);
    }
  }

  async function addGoal(e) {
    e.preventDefault();
    setMsg("");
    try {
      await api.addGoal(goalForm);
      setGoalForm({ skillName: "", category: "", urgency: "Flexible" });
      refresh(user.userId);
      setMsg("Learning goal added!");
    } catch (err) {
      setMsg(err.message);
    }
  }

  async function tryGetCertificate(skillName) {
    try {
      await api.requestCertificate(skillName);
      refresh(user.userId);
      setMsg(`Certificate issued for ${skillName}!`);
    } catch (err) {
      setMsg(err.message);
    }
  }

  async function upgrade(plan) {
    try {
      const res = await api.upgradePremium(plan);
      setMsg(`You're now Premium until ${new Date(res.expiresAt).toLocaleDateString()}!`);
    } catch (err) {
      setMsg(err.message);
    }
  }

  if (!user) return null;

  return (
    <>
      <Navbar user={user} />
      <main className="max-w-4xl mx-auto px-6 py-10 space-y-8">
        <h1 className="text-2xl font-bold">{user.name}'s Profile</h1>
        {msg && <p className="text-brand-700 bg-brand-50 px-4 py-2 rounded-lg text-sm">{msg}</p>}

        <section className="card">
          <h2 className="font-bold text-lg mb-4">Add a skill you know (with proof)</h2>
          <form onSubmit={addSkill} className="grid md:grid-cols-2 gap-3">
            <input className="input" placeholder="Skill name (e.g. SQL)" value={skillForm.skillName}
              onChange={(e) => setSkillForm({ ...skillForm, skillName: e.target.value })} required />
            <input className="input" placeholder="Category (e.g. Programming)" value={skillForm.category}
              onChange={(e) => setSkillForm({ ...skillForm, category: e.target.value })} />
            <select className="input" value={skillForm.proficiency}
              onChange={(e) => setSkillForm({ ...skillForm, proficiency: e.target.value })}>
              <option>Beginner</option><option>Intermediate</option><option>Advanced</option><option>Expert</option>
            </select>
            <select className="input" value={skillForm.proofType}
              onChange={(e) => setSkillForm({ ...skillForm, proofType: e.target.value })}>
              <option value="certificate">Certificate</option>
              <option value="portfolio">Portfolio</option>
              <option value="github">GitHub</option>
              <option value="description">Description only</option>
            </select>
            <input className="input md:col-span-2" placeholder="Proof link (certificate, GitHub, portfolio URL)"
              value={skillForm.proofUrl} onChange={(e) => setSkillForm({ ...skillForm, proofUrl: e.target.value })} />
            <textarea className="input md:col-span-2" placeholder="Or describe your proof (projects done, years of experience, etc.)"
              value={skillForm.proofDescription} onChange={(e) => setSkillForm({ ...skillForm, proofDescription: e.target.value })} />
            <button className="btn-primary md:col-span-2">Add skill</button>
          </form>

          <ul className="mt-5 space-y-2">
            {skills.map((s) => (
              <li key={s.skillId} className="flex justify-between items-center border-b border-slate-100 pb-2 text-sm">
                <span>{s.skillName} <span className="text-slate-400">· {s.proficiency}</span></span>
                <button onClick={() => tryGetCertificate(s.skillName)} className="text-brand-600 text-xs font-semibold">
                  Get certificate
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section className="card">
          <h2 className="font-bold text-lg mb-4">Add a skill you want to learn</h2>
          <form onSubmit={addGoal} className="grid md:grid-cols-2 gap-3">
            <input className="input" placeholder="Skill name (e.g. Photoshop)" value={goalForm.skillName}
              onChange={(e) => setGoalForm({ ...goalForm, skillName: e.target.value })} required />
            <input className="input" placeholder="Category" value={goalForm.category}
              onChange={(e) => setGoalForm({ ...goalForm, category: e.target.value })} />
            <select className="input" value={goalForm.urgency}
              onChange={(e) => setGoalForm({ ...goalForm, urgency: e.target.value })}>
              <option>Flexible</option><option>Soon</option><option>Urgent</option>
            </select>
            <button className="btn-primary">Add goal</button>
          </form>
          <ul className="mt-5 space-y-2">
            {goals.map((g) => (
              <li key={g.skillId} className="text-sm border-b border-slate-100 pb-2">
                {g.skillName} <span className="text-slate-400">· {g.urgency}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="card">
          <h2 className="font-bold text-lg mb-4">Your certificates</h2>
          {certs.length === 0 && <p className="text-slate-500 text-sm">Complete 3+ highly-rated swaps in a skill to unlock a certificate.</p>}
          <ul className="space-y-1">
            {certs.map((c) => (
              <li key={c.certificateId} className="text-sm">
                🏆 {c.skillName} — {c.tier} certificate, avg rating {c.avgRating.toFixed(1)}
              </li>
            ))}
          </ul>
        </section>

        <section className="card">
          <h2 className="font-bold text-lg mb-2">Go Premium</h2>
          <p className="text-slate-500 text-sm mb-4">
            Boosted profile in matches, verified shareable certificates, featured skill listing on the homepage.
          </p>
          <div className="flex gap-3">
            <button className="btn-primary" onClick={() => upgrade("monthly")}>Monthly — $3</button>
            <button className="btn-primary" onClick={() => upgrade("yearly")}>Yearly — $25</button>
          </div>
        </section>
      </main>
    </>
  );
}
