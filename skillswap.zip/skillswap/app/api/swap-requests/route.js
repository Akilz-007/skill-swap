import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { PutCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

// GET /api/swap-requests?direction=incoming|outgoing
export async function GET(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const direction = searchParams.get("direction") || "incoming";

  const IndexName = direction === "outgoing" ? "FromUserIndex" : "ToUserIndex";
  const key = direction === "outgoing" ? "fromUserId" : "toUserId";

  const result = await ddb.send(
    new QueryCommand({
      TableName: TABLES.SWAP_REQUESTS,
      IndexName,
      KeyConditionExpression: `${key} = :u`,
      ExpressionAttributeValues: { ":u": user.userId },
    })
  );

  return NextResponse.json({ requests: result.Items || [] });
}

// POST /api/swap-requests -> send a swap request (this doubles as the "chat request")
// body: { toUserId, offeredSkillId, offeredSkillName, requestedSkillId, requestedSkillName, message }
export async function POST(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { toUserId, offeredSkillId, offeredSkillName, requestedSkillId, requestedSkillName, message } = body;

  if (!toUserId || !requestedSkillId) {
    return NextResponse.json(
      { error: "toUserId and requestedSkillId are required" },
      { status: 400 }
    );
  }
  if (toUserId === user.userId) {
    return NextResponse.json({ error: "You can't send a request to yourself" }, { status: 400 });
  }

  const requestId = nanoid();
  const now = new Date().toISOString();

  const swapRequest = {
    requestId,
    fromUserId: user.userId,
    fromUserName: user.name,
    toUserId,
    offeredSkillId: offeredSkillId || null,
    offeredSkillName: offeredSkillName || null,
    requestedSkillId,
    requestedSkillName: requestedSkillName || "",
    message: message || "",
    status: "pending", // pending | accepted | declined | completed | cancelled
    createdAt: now,
    updatedAt: now,
  };

  await ddb.send(new PutCommand({ TableName: TABLES.SWAP_REQUESTS, Item: swapRequest }));

  // Fire a notification record for the recipient
  await ddb.send(
    new PutCommand({
      TableName: TABLES.NOTIFICATIONS,
      Item: {
        userId: toUserId,
        sortKey: `${now}#${requestId}`,
        type: "swap_request",
        message: `${user.name} wants to swap skills with you`,
        requestId,
        read: false,
        createdAt: now,
      },
    })
  );

  return NextResponse.json({ request: swapRequest }, { status: 201 });
}
