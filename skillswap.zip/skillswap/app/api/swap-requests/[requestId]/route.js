import { NextResponse } from "next/server";
import { GetCommand, UpdateCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

const ALLOWED = ["accepted", "declined", "completed", "cancelled"];

export async function PATCH(req, { params }) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { requestId } = params;
  const { status } = await req.json();

  if (!ALLOWED.includes(status)) {
    return NextResponse.json({ error: `status must be one of ${ALLOWED.join(", ")}` }, { status: 400 });
  }

  const existing = await ddb.send(
    new GetCommand({ TableName: TABLES.SWAP_REQUESTS, Key: { requestId } })
  );
  if (!existing.Item) {
    return NextResponse.json({ error: "Request not found" }, { status: 404 });
  }
  if (existing.Item.toUserId !== user.userId && existing.Item.fromUserId !== user.userId) {
    return NextResponse.json({ error: "Not your request" }, { status: 403 });
  }

  const now = new Date().toISOString();
  await ddb.send(
    new UpdateCommand({
      TableName: TABLES.SWAP_REQUESTS,
      Key: { requestId },
      UpdateExpression: "SET #s = :s, updatedAt = :u",
      ExpressionAttributeNames: { "#s": "status" },
      ExpressionAttributeValues: { ":s": status, ":u": now },
    })
  );

  return NextResponse.json({ requestId, status });
}
