import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { PutCommand, QueryCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

/**
 * Certificates are auto-issued once a user has:
 *  - completed at least 3 swaps teaching the same skill, OR
 *  - received at least 3 reviews of 4+ stars for that skill
 * Free users get a basic certificate; premium users get a verified/branded one
 * with a shareable public link (a small additional revenue lever).
 */
export async function POST(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { skillName } = await req.json();
  if (!skillName) return NextResponse.json({ error: "skillName is required" }, { status: 400 });

  const reviews = await ddb.send(
    new QueryCommand({
      TableName: TABLES.REVIEWS,
      KeyConditionExpression: "revieweeId = :u",
      ExpressionAttributeValues: { ":u": user.userId },
    })
  );

  const relevantReviews = (reviews.Items || []).filter(
    (r) => r.skillTaught && r.skillTaught.toLowerCase() === skillName.toLowerCase() && r.rating >= 4
  );

  if (relevantReviews.length < 3) {
    return NextResponse.json(
      {
        error: `You need at least 3 reviews of 4+ stars for "${skillName}" to unlock a certificate. You currently have ${relevantReviews.length}.`,
      },
      { status: 403 }
    );
  }

  const profile = await ddb.send(new GetCommand({ TableName: TABLES.USERS, Key: { userId: user.userId } }));
  const isPremium = profile.Item?.isPremium || false;

  const certificateId = nanoid();
  const now = new Date().toISOString();

  const certificate = {
    userId: user.userId,
    certificateId,
    skillName,
    issuedAt: now,
    tier: isPremium ? "verified" : "basic",
    publicUrl: isPremium ? `/certificates/${certificateId}` : null,
    avgRating:
      relevantReviews.reduce((sum, r) => sum + r.rating, 0) / relevantReviews.length,
    reviewCount: relevantReviews.length,
  };

  await ddb.send(new PutCommand({ TableName: TABLES.CERTIFICATES, Item: certificate }));
  return NextResponse.json({ certificate }, { status: 201 });
}

export async function GET(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const result = await ddb.send(
    new QueryCommand({
      TableName: TABLES.CERTIFICATES,
      KeyConditionExpression: "userId = :u",
      ExpressionAttributeValues: { ":u": user.userId },
    })
  );
  return NextResponse.json({ certificates: result.Items || [] });
}
