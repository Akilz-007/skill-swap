import { NextResponse } from "next/server";
import { ScanCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";

/**
 * Returns skills taught by premium users first ("featured"), for the homepage carousel.
 * Premium users pay to get their top skill highlighted here -> direct revenue lever.
 * NOTE: uses Scan for the hackathon demo; at real scale, mirror "isPremium" onto
 * UserSkills items (denormalize) and add a GSI on a "featured" flag instead of scanning.
 */
export async function GET() {
  const usersResult = await ddb.send(
    new ScanCommand({
      TableName: TABLES.USERS,
      FilterExpression: "isPremium = :p",
      ExpressionAttributeValues: { ":p": true },
      ProjectionExpression: "userId, #n, ratingAvg, ratingCount, avatarUrl",
      ExpressionAttributeNames: { "#n": "name" },
    })
  );

  const premiumUserIds = (usersResult.Items || []).map((u) => u.userId);
  if (premiumUserIds.length === 0) {
    return NextResponse.json({ featured: [] });
  }

  const skillsResult = await ddb.send(new ScanCommand({ TableName: TABLES.USER_SKILLS }));
  const featured = (skillsResult.Items || [])
    .filter((s) => premiumUserIds.includes(s.userId))
    .slice(0, 12);

  return NextResponse.json({ featured });
}
