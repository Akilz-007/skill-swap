import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { PutCommand, QueryCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

// GET /api/skills?userId=xxx  -> list skills a user knows (with proof)
export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get("userId");
  if (!userId) {
    return NextResponse.json({ error: "userId is required" }, { status: 400 });
  }
  const result = await ddb.send(
    new QueryCommand({
      TableName: TABLES.USER_SKILLS,
      KeyConditionExpression: "userId = :u",
      ExpressionAttributeValues: { ":u": userId },
    })
  );
  return NextResponse.json({ skills: result.Items || [] });
}

// POST /api/skills -> add a skill you know + proof of expertise
// body: { skillName, category, proficiency, proofType, proofUrl, proofDescription }
export async function POST(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { skillName, category, proficiency, proofType, proofUrl, proofDescription } = body;

  if (!skillName || !proficiency) {
    return NextResponse.json(
      { error: "skillName and proficiency are required" },
      { status: 400 }
    );
  }
  if (!proofUrl && !proofDescription) {
    return NextResponse.json(
      { error: "Please provide proof: a link (certificate/portfolio/GitHub) or a description" },
      { status: 400 }
    );
  }

  const skillId = `skill_${skillName.trim().toLowerCase().replace(/\s+/g, "_")}`;
  const now = new Date().toISOString();

  // Upsert into master Skills catalog so it shows up in search/matching
  await ddb.send(
    new PutCommand({
      TableName: TABLES.SKILLS,
      Item: {
        skillId,
        skillName: skillName.trim(),
        skillNameLower: skillName.trim().toLowerCase(),
        category: category || "General",
      },
    })
  );

  const userSkill = {
    userId: user.userId,
    skillId,
    skillName: skillName.trim(),
    category: category || "General",
    proficiency, // Beginner | Intermediate | Advanced | Expert
    proofType: proofType || "description", // certificate | portfolio | github | description
    proofUrl: proofUrl || "",
    proofDescription: proofDescription || "",
    verified: false, // could be flipped by an admin/peer-review flow
    endorsementCount: 0,
    createdAt: now,
  };

  await ddb.send(new PutCommand({ TableName: TABLES.USER_SKILLS, Item: userSkill }));

  return NextResponse.json({ skill: userSkill }, { status: 201 });
}
