import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { PutCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

// Conversation id is just the two userIds sorted & joined so it's deterministic.
function conversationId(a, b) {
  return [a, b].sort().join("__");
}

// GET /api/messages?withUserId=xxx
export async function GET(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const withUserId = searchParams.get("withUserId");
  if (!withUserId) {
    return NextResponse.json({ error: "withUserId is required" }, { status: 400 });
  }

  const convoId = conversationId(user.userId, withUserId);
  const result = await ddb.send(
    new QueryCommand({
      TableName: TABLES.MESSAGES,
      KeyConditionExpression: "conversationId = :c",
      ExpressionAttributeValues: { ":c": convoId },
      ScanIndexForward: true, // oldest first
    })
  );

  return NextResponse.json({ messages: result.Items || [], conversationId: convoId });
}

// POST /api/messages -> send a chat message
// body: { toUserId, text }
export async function POST(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { toUserId, text } = await req.json();
  if (!toUserId || !text || !text.trim()) {
    return NextResponse.json({ error: "toUserId and text are required" }, { status: 400 });
  }

  const convoId = conversationId(user.userId, toUserId);
  const now = new Date().toISOString();
  const messageId = nanoid();

  const message = {
    conversationId: convoId,
    sortKey: `${now}#${messageId}`,
    messageId,
    fromUserId: user.userId,
    fromUserName: user.name,
    toUserId,
    text: text.trim(),
    createdAt: now,
  };

  await ddb.send(new PutCommand({ TableName: TABLES.MESSAGES, Item: message }));
  return NextResponse.json({ message }, { status: 201 });
}
