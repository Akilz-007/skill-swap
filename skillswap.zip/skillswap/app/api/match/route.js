import { NextResponse } from "next/server";
import { QueryCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

/**
 * Matching algorithm:
 * 1. Get the things I want to learn (my LearningGoals).
 * 2. For each goal skillId, query UserSkills.SkillIndex to find everyone who KNOWS it.
 * 3. Get the things I know (my UserSkills).
 * 4. For each candidate found in step 2, check if THEY have a learning goal matching
 *    one of my known skills -> that's a perfect two-way (mutual) match.
 *    If not, it's still a one-way match (they can teach me, I can't yet teach them).
 * 5. Score: mutual matches rank highest, then by rating, then by proficiency level.
 */
export async function GET(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const myGoals = await ddb.send(
    new QueryCommand({
      TableName: TABLES.LEARNING_GOALS,
      KeyConditionExpression: "userId = :u",
      ExpressionAttributeValues: { ":u": user.userId },
    })
  );

  const myKnownSkills = await ddb.send(
    new QueryCommand({
      TableName: TABLES.USER_SKILLS,
      KeyConditionExpression: "userId = :u",
      ExpressionAttributeValues: { ":u": user.userId },
    })
  );
  const myKnownSkillIds = new Set((myKnownSkills.Items || []).map((s) => s.skillId));

  const candidateMap = new Map(); // userId -> { user info, teachableSkills[], theyWantFromMe[] }

  for (const goal of myGoals.Items || []) {
    const teachers = await ddb.send(
      new QueryCommand({
        TableName: TABLES.USER_SKILLS,
        IndexName: "SkillIndex",
        KeyConditionExpression: "skillId = :s",
        ExpressionAttributeValues: { ":s": goal.skillId },
      })
    );

    for (const teacherSkill of teachers.Items || []) {
      if (teacherSkill.userId === user.userId) continue; // skip self

      if (!candidateMap.has(teacherSkill.userId)) {
        candidateMap.set(teacherSkill.userId, {
          userId: teacherSkill.userId,
          theyCanTeachMe: [],
          theyWantFromMe: [],
          mutual: false,
        });
      }
      candidateMap.get(teacherSkill.userId).theyCanTeachMe.push({
        skillId: teacherSkill.skillId,
        skillName: teacherSkill.skillName,
        proficiency: teacherSkill.proficiency,
        verified: teacherSkill.verified,
      });
    }
  }

  // Now check for mutuality: does each candidate have a learning goal matching something I know?
  for (const [candidateId, data] of candidateMap.entries()) {
    const theirGoals = await ddb.send(
      new QueryCommand({
        TableName: TABLES.LEARNING_GOALS,
        KeyConditionExpression: "userId = :u",
        ExpressionAttributeValues: { ":u": candidateId },
      })
    );
    for (const g of theirGoals.Items || []) {
      if (myKnownSkillIds.has(g.skillId)) {
        data.theyWantFromMe.push({ skillId: g.skillId, skillName: g.skillName });
      }
    }
    data.mutual = data.theyWantFromMe.length > 0;

    // Attach basic user profile info
    const profile = await ddb.send(
      new GetCommand({ TableName: TABLES.USERS, Key: { userId: candidateId } })
    );
    if (profile.Item) {
      const { passwordHash, ...safe } = profile.Item;
      data.profile = safe;
    }
  }

  const matches = Array.from(candidateMap.values())
    .filter((m) => m.profile) // drop any orphaned records
    .sort((a, b) => {
      if (a.mutual !== b.mutual) return a.mutual ? -1 : 1;
      const ratingA = a.profile.ratingAvg || 0;
      const ratingB = b.profile.ratingAvg || 0;
      return ratingB - ratingA;
    });

  return NextResponse.json({ matches, count: matches.length });
}
