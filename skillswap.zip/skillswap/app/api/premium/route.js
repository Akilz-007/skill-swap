import { NextResponse } from "next/server";
import { UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

/**
 * In a real deployment this route would be called AFTER a successful Stripe/Razorpay
 * webhook confirms payment. For the hackathon demo it simulates the upgrade directly.
 * Premium perks:
 *  - Profile boosted to top of match results
 *  - Verified certificate badges with public shareable links
 *  - Ability to list skills under "Featured Skills" on the homepage
 *  - No ads / unlimited swap requests per month (free tier capped at 5/month)
 */
export async function POST(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { plan } = await req.json(); // "monthly" | "yearly"
  const validPlans = { monthly: 30, yearly: 365 };
  if (!validPlans[plan]) {
    return NextResponse.json({ error: "plan must be 'monthly' or 'yearly'" }, { status: 400 });
  }

  const now = new Date();
  const expiresAt = new Date(now.getTime() + validPlans[plan] * 24 * 60 * 60 * 1000).toISOString();

  await ddb.send(
    new UpdateCommand({
      TableName: TABLES.USERS,
      Key: { userId: user.userId },
      UpdateExpression: "SET isPremium = :p, premiumPlan = :pl, premiumExpiresAt = :e",
      ExpressionAttributeValues: { ":p": true, ":pl": plan, ":e": expiresAt },
    })
  );

  return NextResponse.json({ isPremium: true, plan, expiresAt });
}
