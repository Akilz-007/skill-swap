import { NextResponse } from "next/server";
import { QueryCommand, GetCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

// One-call summary for the dashboard: profile, skills, goals, pending requests, completed swaps, reviews.
export async function GET(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [profile, mySkills, myGoals, incoming, outgoing, reviews] = await Promise.all([
    ddb.send(new GetCommand({ TableName: TABLES.USERS, Key: { userId: user.userId } })),
    ddb.send(
      new QueryCommand({
        TableName: TABLES.USER_SKILLS,
        KeyConditionExpression: "userId = :u",
        ExpressionAttributeValues: { ":u": user.userId },
      })
    ),
    ddb.send(
      new QueryCommand({
        TableName: TABLES.LEARNING_GOALS,
        KeyConditionExpression: "userId = :u",
        ExpressionAttributeValues: { ":u": user.userId },
      })
    ),
    ddb.send(
      new QueryCommand({
        TableName: TABLES.SWAP_REQUESTS,
        IndexName: "ToUserIndex",
        KeyConditionExpression: "toUserId = :u",
        ExpressionAttributeValues: { ":u": user.userId },
      })
    ),
    ddb.send(
      new QueryCommand({
        TableName: TABLES.SWAP_REQUESTS,
        IndexName: "FromUserIndex",
        KeyConditionExpression: "fromUserId = :u",
        ExpressionAttributeValues: { ":u": user.userId },
      })
    ),
    ddb.send(
      new QueryCommand({
        TableName: TABLES.REVIEWS,
        KeyConditionExpression: "revieweeId = :u",
        ExpressionAttributeValues: { ":u": user.userId },
      })
    ),
  ]);

  const allRequests = [...(incoming.Items || []), ...(outgoing.Items || [])];
  const completedSwaps = allRequests.filter((r) => r.status === "completed").length;
  const pendingRequests = (incoming.Items || []).filter((r) => r.status === "pending").length;

  const { passwordHash, ...safeProfile } = profile.Item || {};

  return NextResponse.json({
    profile: safeProfile,
    skillsKnown: mySkills.Items || [],
    learningGoals: myGoals.Items || [],
    pendingRequestsCount: pendingRequests,
    completedSwapsCount: completedSwaps,
    incomingRequests: incoming.Items || [],
    outgoingRequests: outgoing.Items || [],
    reviews: reviews.Items || [],
    stats: {
      skillsKnownCount: (mySkills.Items || []).length,
      goalsCount: (myGoals.Items || []).length,
      ratingAvg: safeProfile.ratingAvg || 0,
      ratingCount: safeProfile.ratingCount || 0,
    },
  });
}
