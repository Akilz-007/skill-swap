import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { PutCommand, QueryCommand, GetCommand, UpdateCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

// GET /api/reviews?userId=xxx -> all reviews received by a user
export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get("userId");
  if (!userId) return NextResponse.json({ error: "userId is required" }, { status: 400 });

  const result = await ddb.send(
    new QueryCommand({
      TableName: TABLES.REVIEWS,
      KeyConditionExpression: "revieweeId = :u",
      ExpressionAttributeValues: { ":u": userId },
      ScanIndexForward: false,
    })
  );
  return NextResponse.json({ reviews: result.Items || [] });
}

// POST /api/reviews -> leave a review after a completed swap
// body: { revieweeId, requestId, rating (1-5), comment, skillTaught }
export async function POST(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { revieweeId, requestId, rating, comment, skillTaught } = await req.json();

  if (!revieweeId || !rating || rating < 1 || rating > 5) {
    return NextResponse.json(
      { error: "revieweeId and a rating between 1-5 are required" },
      { status: 400 }
    );
  }

  const reviewId = nanoid();
  const now = new Date().toISOString();

  const review = {
    revieweeId,
    reviewId,
    reviewerId: user.userId,
    reviewerName: user.name,
    requestId: requestId || null,
    rating,
    comment: comment || "",
    skillTaught: skillTaught || "",
    createdAt: now,
  };

  await ddb.send(new PutCommand({ TableName: TABLES.REVIEWS, Item: review }));

  // Recalculate the reviewee's running average rating
  const profile = await ddb.send(new GetCommand({ TableName: TABLES.USERS, Key: { userId: revieweeId } }));
  if (profile.Item) {
    const prevCount = profile.Item.ratingCount || 0;
    const prevAvg = profile.Item.ratingAvg || 0;
    const newCount = prevCount + 1;
    const newAvg = (prevAvg * prevCount + rating) / newCount;

    await ddb.send(
      new UpdateCommand({
        TableName: TABLES.USERS,
        Key: { userId: revieweeId },
        UpdateExpression: "SET ratingAvg = :a, ratingCount = :c",
        ExpressionAttributeValues: { ":a": newAvg, ":c": newCount },
      })
    );
  }

  return NextResponse.json({ review }, { status: 201 });
}
