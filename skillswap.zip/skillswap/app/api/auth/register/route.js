import { NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { PutCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { hashPassword, signToken } from "@/lib/auth";

export async function POST(req) {
  try {
    const body = await req.json();
    const { name, email, password, college, bio } = body;

    if (!name || !email || !password) {
      return NextResponse.json(
        { error: "name, email, and password are required" },
        { status: 400 }
      );
    }
    if (password.length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters" },
        { status: 400 }
      );
    }

    // Check if email already exists
    const existing = await ddb.send(
      new QueryCommand({
        TableName: TABLES.USERS,
        IndexName: "EmailIndex",
        KeyConditionExpression: "email = :e",
        ExpressionAttributeValues: { ":e": email.toLowerCase() },
      })
    );
    if (existing.Items && existing.Items.length > 0) {
      return NextResponse.json(
        { error: "An account with this email already exists" },
        { status: 409 }
      );
    }

    const userId = nanoid();
    const passwordHash = await hashPassword(password);
    const now = new Date().toISOString();

    const user = {
      userId,
      name,
      email: email.toLowerCase(),
      passwordHash,
      college: college || "",
      bio: bio || "",
      avatarUrl: "",
      isPremium: false,
      credits: 3, // starter credits to incentivize first swaps
      ratingAvg: 0,
      ratingCount: 0,
      createdAt: now,
    };

    await ddb.send(new PutCommand({ TableName: TABLES.USERS, Item: user }));

    const token = signToken({ userId, email: user.email, name });
    const { passwordHash: _, ...safeUser } = user;

    const res = NextResponse.json({ user: safeUser, token }, { status: 201 });
    res.cookies.set("token", token, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });
    return res;
  } catch (err) {
    console.error("Register error:", err);
    return NextResponse.json(
      { error: "Something went wrong while creating your account" },
      { status: 500 }
    );
  }
}
