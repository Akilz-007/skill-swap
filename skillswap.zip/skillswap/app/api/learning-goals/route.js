import { NextResponse } from "next/server";
import { PutCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { ddb, TABLES } from "@/lib/dynamodb";
import { getUserFromRequest } from "@/lib/auth";

// GET /api/learning-goals?userId=xxx
export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const userId = searchParams.get("userId");
  if (!userId) {
    return NextResponse.json({ error: "userId is required" }, { status: 400 });
  }
  const result = await ddb.send(
    new QueryCommand({
      TableName: TABLES.LEARNING_GOALS,
      KeyConditionExpression: "userId = :u",
      ExpressionAttributeValues: { ":u": userId },
    })
  );
  return NextResponse.json({ goals: result.Items || [] });
}

// POST /api/learning-goals -> add a skill you WANT to learn
// body: { skillName, category, urgency, targetLevel }
export async function POST(req) {
  const user = getUserFromRequest(req);
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { skillName, category, urgency, targetLevel } = await req.json();
  if (!skillName) {
    return NextResponse.json({ error: "skillName is required" }, { status: 400 });
  }

  const skillId = `skill_${skillName.trim().toLowerCase().replace(/\s+/g, "_")}`;
  const now = new Date().toISOString();

  const goal = {
    userId: user.userId,
    skillId,
    skillName: skillName.trim(),
    category: category || "General",
    urgency: urgency || "Flexible", // Urgent | Soon | Flexible
    targetLevel: targetLevel || "Beginner",
    createdAt: now,
  };

  await ddb.send(new PutCommand({ TableName: TABLES.LEARNING_GOALS, Item: goal }));
  return NextResponse.json({ goal }, { status: 201 });
}
