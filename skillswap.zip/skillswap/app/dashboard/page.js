"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";

export default function DashboardPage() {
  const router = useRouter();
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [user, setUser] = useState(null);

  useEffect(() => {
    const stored = localStorage.getItem("user");
    if (!stored) {
      router.push("/login");
      return;
    }
    setUser(JSON.parse(stored));
    api.dashboard().then(setData).catch((e) => setError(e.message));
  }, [router]);

  async function respond(requestId, status) {
    await api.updateSwapRequest(requestId, status);
    const fresh = await api.dashboard();
    setData(fresh);
  }

  if (error) return <p className="p-8 text-red-600">{error}</p>;
  if (!data) return <p className="p-8">Loading your dashboard...</p>;

  const { profile, stats, skillsKnown, learningGoals, incomingRequests } = data;

  return (
    <>
      <Navbar user={user} />
      <main className="max-w-5xl mx-auto px-6 py-10">
        <h1 className="text-2xl font-bold mb-1">Welcome back, {profile.name} 👋</h1>
        <p className="text-slate-500 mb-8">{profile.college || "Add your college in your profile"}</p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <StatCard label="Skills you teach" value={stats.skillsKnownCount} />
          <StatCard label="Skills you want" value={stats.goalsCount} />
          <StatCard label="Avg rating" value={stats.ratingAvg ? stats.ratingAvg.toFixed(1) : "—"} />
          <StatCard label="Reviews" value={stats.ratingCount} />
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <section className="card">
            <h2 className="font-bold text-lg mb-4">Pending swap requests</h2>
            {incomingRequests.filter((r) => r.status === "pending").length === 0 && (
              <p className="text-slate-500 text-sm">No pending requests right now.</p>
            )}
            {incomingRequests
              .filter((r) => r.status === "pending")
              .map((r) => (
                <div key={r.requestId} className="border border-slate-200 rounded-lg p-3 mb-2">
                  <p className="text-sm">
                    <span className="font-semibold">{r.fromUserName}</span> wants to learn{" "}
                    <span className="font-semibold">{r.requestedSkillName}</span> from you
                    {r.offeredSkillName ? (
                      <> in exchange for teaching you <span className="font-semibold">{r.offeredSkillName}</span></>
                    ) : null}
                  </p>
                  {r.message && <p className="text-slate-500 text-sm mt-1">"{r.message}"</p>}
                  <div className="flex gap-2 mt-2">
                    <button className="btn-primary text-sm px-3 py-1" onClick={() => respond(r.requestId, "accepted")}>
                      Accept
                    </button>
                    <button
                      className="text-sm px-3 py-1 rounded-lg border border-slate-300"
                      onClick={() => respond(r.requestId, "declined")}
                    >
                      Decline
                    </button>
                  </div>
                </div>
              ))}
          </section>

          <section className="card">
            <h2 className="font-bold text-lg mb-4">Your skills</h2>
            {skillsKnown.length === 0 && <p className="text-slate-500 text-sm">No skills added yet.</p>}
            <ul className="space-y-2">
              {skillsKnown.map((s) => (
                <li key={s.skillId} className="flex justify-between text-sm border-b border-slate-100 pb-2">
                  <span>{s.skillName}</span>
                  <span className="text-slate-500">{s.proficiency}</span>
                </li>
              ))}
            </ul>
            <a href="/profile" className="text-brand-600 text-sm font-semibold mt-3 inline-block">
              + Add a skill
            </a>
          </section>

          <section className="card">
            <h2 className="font-bold text-lg mb-4">You want to learn</h2>
            {learningGoals.length === 0 && <p className="text-slate-500 text-sm">No learning goals added yet.</p>}
            <ul className="space-y-2">
              {learningGoals.map((g) => (
                <li key={g.skillId} className="flex justify-between text-sm border-b border-slate-100 pb-2">
                  <span>{g.skillName}</span>
                  <span className="text-slate-500">{g.urgency}</span>
                </li>
              ))}
            </ul>
            <a href="/profile" className="text-brand-600 text-sm font-semibold mt-3 inline-block">
              + Add a goal
            </a>
          </section>

          <section className="card">
            <h2 className="font-bold text-lg mb-4">Find your match</h2>
            <p className="text-slate-500 text-sm mb-3">
              See students who can teach you what you want to learn — and who want what you know.
            </p>
            <a href="/matches" className="btn-primary inline-block">Browse matches</a>
          </section>
        </div>
      </main>
    </>
  );
}

function StatCard({ label, value }) {
  return (
    <div className="card text-center">
      <p className="text-2xl font-bold text-brand-600">{value}</p>
      <p className="text-xs text-slate-500 mt-1">{label}</p>
    </div>
  );
}
