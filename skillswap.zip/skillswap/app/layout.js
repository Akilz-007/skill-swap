import "./globals.css";

export const metadata = {
  title: "SkillSwap — Trade Skills, Not Money",
  description: "Students teach each other skills they know in exchange for skills they want to learn.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="min-h-screen text-slate-800">{children}</body>
    </html>
  );
}
