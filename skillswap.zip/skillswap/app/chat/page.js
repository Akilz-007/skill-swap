"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";

export default function ChatPage() {
  const router = useRouter();
  const params = useSearchParams();
  const withUserId = params.get("with");
  const withName = params.get("name") || "this student";

  const [user, setUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const bottomRef = useRef(null);

  useEffect(() => {
    const stored = localStorage.getItem("user");
    if (!stored) {
      router.push("/login");
      return;
    }
    setUser(JSON.parse(stored));
  }, [router]);

  useEffect(() => {
    if (!withUserId) return;
    let active = true;
    async function load() {
      const data = await api.getMessages(withUserId);
      if (active) setMessages(data.messages);
    }
    load();
    // Poll every 3 seconds to simulate real-time chat without a websocket server.
    const interval = setInterval(load, 3000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [withUserId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send(e) {
    e.preventDefault();
    if (!text.trim()) return;
    const newMsg = await api.sendMessage({ toUserId: withUserId, text });
    setMessages((m) => [...m, newMsg.message]);
    setText("");
  }

  if (!user) return null;

  return (
    <>
      <Navbar user={user} />
      <main className="max-w-2xl mx-auto px-6 py-10">
        <h1 className="text-xl font-bold mb-4">Chat with {withName}</h1>
        <div className="card h-96 overflow-y-auto flex flex-col gap-2">
          {messages.map((m) => (
            <div
              key={m.messageId}
              className={`max-w-[75%] px-3 py-2 rounded-lg text-sm ${
                m.fromUserId === user.userId
                  ? "bg-brand-600 text-white self-end"
                  : "bg-slate-100 self-start"
              }`}
            >
              {m.text}
            </div>
          ))}
          <div ref={bottomRef} />
        </div>
        <form onSubmit={send} className="flex gap-2 mt-4">
          <input className="input" placeholder="Type a message..." value={text} onChange={(e) => setText(e.target.value)} />
          <button className="btn-primary">Send</button>
        </form>
      </main>
    </>
  );
}
