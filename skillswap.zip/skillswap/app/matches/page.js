"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/api";
import Navbar from "@/components/Navbar";

export default function MatchesPage() {
  const router = useRouter();
  const [user, setUser] = useState(null);
  const [matches, setMatches] = useState([]);
  const [error, setError] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const stored = localStorage.getItem("user");
    if (!stored) {
      router.push("/login");
      return;
    }
    setUser(JSON.parse(stored));
    api.getMatches().then((d) => setMatches(d.matches)).catch((e) => setError(e.message));
  }, [router]);

  async function sendRequest(match, teachSkill) {
    const offered = match.theyWantFromMe[0];
    try {
      await api.sendSwapRequest({
        toUserId: match.userId,
        offeredSkillId: offered?.skillId || null,
        offeredSkillName: offered?.skillName || null,
        requestedSkillId: teachSkill.skillId,
        requestedSkillName: teachSkill.skillName,
        message: `Hi! I'd love to learn ${teachSkill.skillName} from you.`,
      });
      setMsg(`Request sent to ${match.profile.name}!`);
    } catch (err) {
      setMsg(err.message);
    }
  }

  if (!user) return null;

  return (
    <>
      <Navbar user={user} />
      <main className="max-w-4xl mx-auto px-6 py-10">
        <h1 className="text-2xl font-bold mb-2">Your matches</h1>
        <p className="text-slate-500 mb-6">
          Mutual matches (they want what you know too) are ranked first.
        </p>
        {msg && <p className="text-brand-700 bg-brand-50 px-4 py-2 rounded-lg text-sm mb-4">{msg}</p>}
        {error && <p className="text-red-600">{error}</p>}
        {matches.length === 0 && (
          <p className="text-slate-500">
            No matches yet — add more skills and learning goals on your{" "}
            <a href="/profile" className="text-brand-600 font-semibold">profile</a>.
          </p>
        )}
        <div className="space-y-4">
          {matches.map((m) => (
            <div key={m.userId} className="card">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-bold text-lg">{m.profile.name}</h3>
                  <p className="text-slate-500 text-sm">{m.profile.college}</p>
                  {m.mutual && (
                    <span className="inline-block mt-1 text-xs bg-brand-50 text-brand-700 px-2 py-0.5 rounded-full font-semibold">
                      🔁 Mutual match
                    </span>
                  )}
                </div>
                <div className="text-right text-sm text-slate-500">
                  ⭐ {(m.profile.ratingAvg || 0).toFixed(1)} ({m.profile.ratingCount || 0})
                </div>
              </div>

              <div className="mt-3">
                <p className="text-sm font-semibold mb-1">Can teach you:</p>
                <div className="flex flex-wrap gap-2">
                  {m.theyCanTeachMe.map((s) => (
                    <button
                      key={s.skillId}
                      onClick={() => sendRequest(m, s)}
                      className="text-xs border border-brand-500 text-brand-700 px-3 py-1 rounded-full hover:bg-brand-50"
                    >
                      {s.skillName} ({s.proficiency}) — Request
                    </button>
                  ))}
                </div>
              </div>

              {m.theyWantFromMe.length > 0 && (
                <div className="mt-3">
                  <p className="text-sm font-semibold mb-1">Wants to learn from you:</p>
                  <div className="flex flex-wrap gap-2">
                    {m.theyWantFromMe.map((s) => (
                      <span key={s.skillId} className="text-xs bg-slate-100 px-3 py-1 rounded-full">
                        {s.skillName}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <a href={`/chat?with=${m.userId}&name=${encodeURIComponent(m.profile.name)}`} className="text-brand-600 text-sm font-semibold mt-3 inline-block">
                Message {m.profile.name} →
              </a>
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
