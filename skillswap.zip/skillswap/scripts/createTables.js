/**
 * Run with: node scripts/createTables.js
 * Creates all DynamoDB tables + GSIs needed by SkillSwap.
 *
 * Design notes:
 * - Users: PK userId. GSI on email for login lookups.
 * - Skills: master catalog. PK skillId. GSI on skillName (lowercased) for search.
 * - UserSkills: PK userId, SK skillId. GSI "SkillIndex" (PK skillId) lets us find
 *   everyone who KNOWS a given skill -> this is the heart of the matching engine.
 * - LearningGoals: PK userId, SK skillId. GSI "SkillIndex" (PK skillId) lets us find
 *   everyone who WANTS a given skill.
 * - SwapRequests: PK requestId. GSI on fromUserId and toUserId to list a user's requests.
 * - Reviews: PK revieweeId, SK reviewId -> fetch all reviews for a user instantly.
 * - Messages: PK conversationId (sorted pair of userIds), SK timestamp#messageId.
 * - Certificates: PK userId, SK certificateId.
 */
const {
  DynamoDBClient,
  CreateTableCommand,
  waitUntilTableExists,
  ListTablesCommand,
} = require("@aws-sdk/client-dynamodb");
require("dotenv").config({ path: ".env.local" });

const client = new DynamoDBClient({
  region: process.env.AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const PREFIX = process.env.DYNAMODB_TABLE_PREFIX || "skillswap_dev";
const PAY_PER_REQUEST = { BillingMode: "PAY_PER_REQUEST" };

const tableDefs = [
  {
    TableName: `${PREFIX}_Users`,
    KeySchema: [{ AttributeName: "userId", KeyType: "HASH" }],
    AttributeDefinitions: [
      { AttributeName: "userId", AttributeType: "S" },
      { AttributeName: "email", AttributeType: "S" },
    ],
    GlobalSecondaryIndexes: [
      {
        IndexName: "EmailIndex",
        KeySchema: [{ AttributeName: "email", KeyType: "HASH" }],
        Projection: { ProjectionType: "ALL" },
      },
    ],
    ...PAY_PER_REQUEST,
  },
  {
    TableName: `${PREFIX}_Skills`,
    KeySchema: [{ AttributeName: "skillId", KeyType: "HASH" }],
    AttributeDefinitions: [
      { AttributeName: "skillId", AttributeType: "S" },
      { AttributeName: "skillNameLower", AttributeType: "S" },
    ],
    GlobalSecondaryIndexes: [
      {
        IndexName: "NameIndex",
        KeySchema: [{ AttributeName: "skillNameLower", KeyType: "HASH" }],
        Projection: { ProjectionType: "ALL" },
      },
    ],
    ...PAY_PER_REQUEST,
  },
  {
    TableName: `${PREFIX}_UserSkills`,
    KeySchema: [
      { AttributeName: "userId", KeyType: "HASH" },
      { AttributeName: "skillId", KeyType: "RANGE" },
    ],
    AttributeDefinitions: [
      { AttributeName: "userId", AttributeType: "S" },
      { AttributeName: "skillId", AttributeType: "S" },
    ],
    GlobalSecondaryIndexes: [
      {
        IndexName: "SkillIndex",
        KeySchema: [
          { AttributeName: "skillId", KeyType: "HASH" },
          { AttributeName: "userId", KeyType: "RANGE" },
        ],
        Projection: { ProjectionType: "ALL" },
      },
    ],
    ...PAY_PER_REQUEST,
  },
  {
    TableName: `${PREFIX}_LearningGoals`,
    KeySchema: [
      { AttributeName: "userId", KeyType: "HASH" },
      { AttributeName: "skillId", KeyType: "RANGE" },
    ],
    AttributeDefinitions: [
      { AttributeName: "userId", AttributeType: "S" },
      { AttributeName: "skillId", AttributeType: "S" },
    ],
    GlobalSecondaryIndexes: [
      {
        IndexName: "SkillIndex",
        KeySchema: [
          { AttributeName: "skillId", KeyType: "HASH" },
          { AttributeName: "userId", KeyType: "RANGE" },
        ],
        Projection: { ProjectionType: "ALL" },
      },
    ],
    ...PAY_PER_REQUEST,
  },
  {
    TableName: `${PREFIX}_SwapRequests`,
    KeySchema: [{ AttributeName: "requestId", KeyType: "HASH" }],
    AttributeDefinitions: [
      { AttributeName: "requestId", AttributeType: "S" },
      { AttributeName: "fromUserId", AttributeType: "S" },
      { AttributeName: "toUserId", AttributeType: "S" },
    ],
    GlobalSecondaryIndexes: [
      {
        IndexName: "FromUserIndex",
        KeySchema: [{ AttributeName: "fromUserId", KeyType: "HASH" }],
        Projection: { ProjectionType: "ALL" },
      },
      {
        IndexName: "ToUserIndex",
        KeySchema: [{ AttributeName: "toUserId", KeyType: "HASH" }],
        Projection: { ProjectionType: "ALL" },
      },
    ],
    ...PAY_PER_REQUEST,
  },
  {
    TableName: `${PREFIX}_Reviews`,
    KeySchema: [
      { AttributeName: "revieweeId", KeyType: "HASH" },
      { AttributeName: "reviewId", KeyType: "RANGE" },
    ],
    AttributeDefinitions: [
      { AttributeName: "revieweeId", AttributeType: "S" },
      { AttributeName: "reviewId", AttributeType: "S" },
    ],
    ...PAY_PER_REQUEST,
  },
  {
    TableName: `${PREFIX}_Messages`,
    KeySchema: [
      { AttributeName: "conversationId", KeyType: "HASH" },
      { AttributeName: "sortKey", KeyType: "RANGE" },
    ],
    AttributeDefinitions: [
      { AttributeName: "conversationId", AttributeType: "S" },
      { AttributeName: "sortKey", AttributeType: "S" },
    ],
    ...PAY_PER_REQUEST,
  },
  {
    TableName: `${PREFIX}_Certificates`,
    KeySchema: [
      { AttributeName: "userId", KeyType: "HASH" },
      { AttributeName: "certificateId", KeyType: "RANGE" },
    ],
    AttributeDefinitions: [
      { AttributeName: "userId", AttributeType: "S" },
      { AttributeName: "certificateId", AttributeType: "S" },
    ],
    ...PAY_PER_REQUEST,
  },
  {
    TableName: `${PREFIX}_Notifications`,
    KeySchema: [
      { AttributeName: "userId", KeyType: "HASH" },
      { AttributeName: "sortKey", KeyType: "RANGE" },
    ],
    AttributeDefinitions: [
      { AttributeName: "userId", AttributeType: "S" },
      { AttributeName: "sortKey", AttributeType: "S" },
    ],
    ...PAY_PER_REQUEST,
  },
];

async function main() {
  const existing = await client.send(new ListTablesCommand({}));
  const existingNames = new Set(existing.TableNames || []);

  for (const def of tableDefs) {
    if (existingNames.has(def.TableName)) {
      console.log(`✓ ${def.TableName} already exists, skipping`);
      continue;
    }
    console.log(`Creating ${def.TableName} ...`);
    await client.send(new CreateTableCommand(def));
    await waitUntilTableExists(
      { client, maxWaitTime: 120 },
      { TableName: def.TableName }
    );
    console.log(`✓ ${def.TableName} created`);
  }
  console.log("All tables ready.");
}

main().catch((err) => {
  console.error("Failed creating tables:", err);
  process.exit(1);
});
