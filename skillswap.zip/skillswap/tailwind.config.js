/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#f0f9ff",
          500: "#0ea5a6",
          600: "#0b8a8b",
          700: "#076e6f",
        },
      },
    },
  },
  plugins: [],
};
