"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Navbar({ user }) {
  const router = useRouter();

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    router.push("/login");
  }

  return (
    <nav className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200">
      <Link href="/dashboard" className="text-xl font-bold text-brand-600">
        SkillSwap
      </Link>
      <div className="flex items-center gap-5 text-sm font-medium">
        <Link href="/dashboard">Dashboard</Link>
        <Link href="/matches">Matches</Link>
        <Link href="/profile">My Profile</Link>
        {user ? (
          <button onClick={logout} className="text-red-600">
            Log out
          </button>
        ) : (
          <Link href="/login">Log in</Link>
        )}
      </div>
    </nav>
  );
}
